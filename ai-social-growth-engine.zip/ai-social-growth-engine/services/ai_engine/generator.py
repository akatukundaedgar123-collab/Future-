import os

def generate_post(topic: str, platform: str):

    prompt = f\"Create a viral {platform} post about {topic}. Include hook and hashtags.\"

    return f\"[AI GENERATED POST] {prompt}\"