# AI Social Growth Engine MVP

## Run Backend
cd apps/api
pip install -r requirements.txt
uvicorn main:app --reload

## Run Frontend
cd apps/web
npm install
npm start