from fastapi import FastAPI
from services.ai_engine.generator import generate_post

app = FastAPI(title="AI Social Growth Engine")

@app.get("/")
def home():
    return {"status": "running"}

@app.post("/generate")
def generate(topic: str, platform: str = "instagram"):
    post = generate_post(topic, platform)
    return {"platform": platform, "post": post}