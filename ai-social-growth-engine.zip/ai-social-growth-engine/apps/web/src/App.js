import { useState } from "react";

function App() {
  const [topic, setTopic] = useState("");
  const [post, setPost] = useState("");

  const generate = async () => {
    const res = await fetch(`http://localhost:8000/generate?topic=${topic}`);
    const data = await res.json();
    setPost(data.post);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>AI Social Growth Engine</h1>

      <input
        placeholder="Enter topic"
        onChange={(e) => setTopic(e.target.value)}
      />

      <button onClick={generate}>Generate</button>

      <pre>{post}</pre>
    </div>
  );
}

export default App;