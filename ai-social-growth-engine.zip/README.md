# AI Social Growth Engine (SaaS Starter)

## Run locally

### Backend
cd apps/api
pip install -r requirements.txt
uvicorn main:app --reload

### Frontend
Open apps/web/index.html in browser

## Docker
docker-compose up --build

## Features
- FastAPI backend
- Simple AI post generator stub
- Web dashboard
- Docker ready