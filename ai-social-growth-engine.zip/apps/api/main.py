from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AI Social Growth Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"status": "running", "message": "AI SaaS Engine Live"}

@app.post("/generate")
def generate(payload: dict):
    topic = payload.get("topic", "")
    platform = payload.get("platform", "instagram")

    return {
        "platform": platform,
        "topic": topic,
        "generated_post": f"[AI POST] {topic} for {platform}"
    }